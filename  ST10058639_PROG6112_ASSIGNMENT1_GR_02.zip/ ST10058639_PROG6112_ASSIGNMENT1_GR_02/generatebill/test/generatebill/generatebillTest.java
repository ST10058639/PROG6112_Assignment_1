/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package generatebill;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import java.util.Scanner;

public class generatebillTest {
    
    private RunApplication app;

    @Before
    public void setUp() {
        app = new RunApplication();
    }

    @Test
    public void testInputNameValid() {
        String input = "John Doe";
        String result = app.inputName(new Scanner(input), "Enter name: ");
        assertEquals("John Doe", result);
    }

    @Test
    public void testInputBillValid() {
        String input = "100.0";
        double result = app.inputBill(new Scanner(input), "Enter bill: ");
        assertEquals(100.0, result, 0.01);
    }

    @Test
    public void testAskAnotherCustomerYes() {
        String input = "yes";
        boolean result = app.askAnotherCustomer(new Scanner(input));
        assertTrue(result);
    }

    @Test
    public void testAskAnotherCustomerNo() {
        String input = "no";
        boolean result = app.askAnotherCustomer(new Scanner(input));
        assertFalse(result);
    }
}