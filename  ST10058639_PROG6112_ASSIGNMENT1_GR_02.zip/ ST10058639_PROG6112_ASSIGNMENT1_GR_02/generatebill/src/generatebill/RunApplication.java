/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
*/

//This Java code is designed to manage and calculate electricity bills for customers. 
//It provides functionality for inputting customer details, calculating increased bills, and generating a summary report. 
package generatebill;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Pattern;

public class RunApplication {
    private ArrayList<CustomerBill> customerBills = new ArrayList<>();

    public void run() {
        Scanner scanner = new Scanner(System.in);
        boolean anotherCustomer = true;

        while (anotherCustomer) {
            String firstName = inputName(scanner, "Enter customer first name: ");
            String surname = inputName(scanner, "Enter customer surname: ");
            double bill = inputBill(scanner, "Enter monthly bill amount (in Rands): ");
            
            CustomerBill customerBill = new CustomerBill(firstName, surname, bill);
            customerBill.printIncreasedBill();
            customerBills.add(customerBill);

            anotherCustomer = askAnotherCustomer(scanner);
        }

        // Print report of all customer bills
        printReport();

        scanner.close();
    }

    // Code attribution:
    // This code was adapted from a Stack Overflow post by [Rahul Sahay].
    // Original post: [https://stackoverflow.com/questions/15805555/java-regex-to-validate-full-name-allow-only-spaces-and-letters]
    // Accessed on: [03/09/2024]
    protected String inputName(Scanner scanner, String prompt) {
        String name;
        while (true) {
            System.out.print(prompt);
            name = scanner.nextLine().trim();
            if (Pattern.matches("^[a-zA-Z\\s-]+$", name)) {
                break;
            } else {
                System.out.println("Invalid name. Please enter a valid name (letters, spaces, or hyphens only).");
            }
        }
        return name;
    }

    protected double inputBill(Scanner scanner, String prompt) {
        double bill = 0;
        boolean validInput = false;
        while (!validInput) {
            System.out.print(prompt);
            if (scanner.hasNextDouble()) {
                bill = scanner.nextDouble();
                if (bill >= 0) {
                    validInput = true;
                } else {
                    System.out.println("Bill amount cannot be negative. Please enter a valid amount.");
                }
            } else {
                System.out.println("Invalid input. Please enter a valid number.");
            }
            scanner.nextLine(); // Clear the input buffer
        }
        return bill;
    }

    protected boolean askAnotherCustomer(Scanner scanner) {
        boolean validResponse = false;
        boolean anotherCustomer = true;
        while (!validResponse) {
            System.out.print("Would you like to calculate the bill for another customer? (yes/no): ");
            String response = scanner.nextLine().trim().toLowerCase();
            if (response.equals("yes")) {
                anotherCustomer = true;
                validResponse = true;
            } else if (response.equals("no")) {
                anotherCustomer = false;
                validResponse = true;
            } else {
                System.out.println("Invalid response. Please enter 'yes' or 'no'.");
            }
        }
        return anotherCustomer;
    }

    private void printReport() {
        System.out.println("                                             ");
        System.out.println("********************************************");
        System.out.println("Customer Bills Report:");
        System.out.println("********************************************");
        System.out.println("                                             ");
        double totalBill = 0;
        double highestBill = 0;
        double lowestBill = Double.MAX_VALUE;
        int i = 1; 

        for (CustomerBill cb : customerBills) {
            System.out.println("Customer : " + i++);
            System.out.println("-------------------------------");
            System.out.println("Customer Name: " + cb.getCustomerName());
            System.out.println("Monthly Electricity Bill: R" + cb.getCustomerMonthlyBill());
            System.out.println("Increased Bill: R" + cb.getCustomerIncreasedBill());
            System.out.println("-------------------------------");
            System.out.println("                                             ");

            double currentBill = cb.getCustomerMonthlyBill();
            totalBill += currentBill;
            if (currentBill > highestBill) highestBill = currentBill;
            if (currentBill < lowestBill) lowestBill = currentBill;
        }

        System.out.println("Summary:");
        System.out.println("Total Customers: " + customerBills.size());
        System.out.println("Average Bill: R" + (totalBill / customerBills.size()));
        System.out.println("Highest Bill: R" + highestBill);
        System.out.println("Lowest Bill: R" + lowestBill);
    }

    public static void main(String[] args) {
        RunApplication app = new RunApplication();
        app.run();
    }
}

// GenerateBill class implementing iCustomer interface
class GenerateBill implements iCustomer {
    private String customerFirstName;
    private String customerSurname;
    private double electricityBill;

    public GenerateBill(String firstName, String surname, double bill) {
        customerFirstName = firstName;
        customerSurname = surname;
        electricityBill = bill;
    }

    @Override
    public String getCustomerName() {
        return customerFirstName + " " + customerSurname;
    }

    @Override
    public double getCustomerMonthlyBill() {
        return electricityBill;
    }

    @Override
    public double getCustomerIncreasedBill() {
        return electricityBill * 1.2; // 20% increase
    }
}

// CustomerBill subclass of GenerateBill
class CustomerBill extends GenerateBill {
    public CustomerBill(String firstName, String surname, double bill) {
        super(firstName, surname, bill);
    }

    public void printIncreasedBill() {
        System.out.println("Customer Name: " + getCustomerName());
        System.out.println("Monthly Bill: R" + getCustomerMonthlyBill());
        System.out.println("Increased Bill: R" + getCustomerIncreasedBill());
    }
}
 // Code attribution:
 // This code was adapted from a GeeksforGeeks
 // Original post: [https://www.geeksforgeeks.org/interfaces-in-java/]
 // Accessed on: [03/09/2024]


// iCustomer interface
interface iCustomer {
    String getCustomerName();
    double getCustomerMonthlyBill();
    double getCustomerIncreasedBill();
}