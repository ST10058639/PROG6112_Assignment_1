/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import abccollege.Student;
import java.util.ArrayList;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class StudentTest {
    private ArrayList<Student> studentList;

    @BeforeEach
    public void setUp() {
        studentList = new ArrayList<>();
    }

    @Test
    public void testSaveStudent() {
        // Arrange
        String studentID = "ID1";
        String firstName = "John";
        String lastName = "Doe";
        String course = "Computer Science";
        int age = 20;

        // Act
        Student newStudent = new Student(studentID, firstName, lastName, course, age);
        studentList.add(newStudent);

        // Assert
        assertEquals(1, studentList.size(), "Student list should contain 1 student");
        Student savedStudent = studentList.get(0);
        assertEquals(studentID, savedStudent.getStudentID(), "Student ID should match");
        assertEquals(firstName, savedStudent.getFirstName(), "First name should match");
        assertEquals(lastName, savedStudent.getLastName(), "Last name should match");
        assertEquals(course, savedStudent.getCourse(), "Course should match");
        assertEquals(age, savedStudent.getAge(), "Age should match");
    }

    @Test
    public void testSearchStudent() {
        // Arrange
        String studentID = "ID1";
        String firstName = "John";
        String lastName = "Doe";
        String course = "Computer Science";
        int age = 20;
        Student newStudent = new Student(studentID, firstName, lastName, course, age);
        studentList.add(newStudent);

        // Act
        Student foundStudent = Student.SearchStudent(studentID, studentList);

        // Assert
        assertNotNull(foundStudent, "Student should be found");
        assertEquals(studentID, foundStudent.getStudentID(), "Student ID should match");
        assertEquals(firstName, foundStudent.getFirstName(), "First name should match");
        assertEquals(lastName, foundStudent.getLastName(), "Last name should match");
        assertEquals(course, foundStudent.getCourse(), "Course should match");
        assertEquals(age, foundStudent.getAge(), "Age should match");
    }

    @Test
    public void testSearchStudent_StudentNotFound() {
        // Arrange
        String validStudentID = "ID1";
        String invalidStudentID = "ID999";
        String firstName = "John";
        String lastName = "Doe";
        String course = "Computer Science";
        int age = 20;
        Student newStudent = new Student(validStudentID, firstName, lastName, course, age);
        studentList.add(newStudent);

        // Act
        Student foundStudent = Student.SearchStudent(invalidStudentID, studentList);

        // Assert
        assertNull(foundStudent, "Student should not be found");
    }
}

