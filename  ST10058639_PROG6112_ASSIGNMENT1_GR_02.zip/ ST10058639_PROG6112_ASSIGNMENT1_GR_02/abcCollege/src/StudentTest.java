/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import abccollege.Student;
import java.util.ArrayList;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class StudentTest {
    private ArrayList<Student> studentList;

    @BeforeEach
    public void setUp() {
        studentList = new ArrayList<>();
    }

    @Test
    public void testSaveStudent() {
        // Arrange
        String studentID = "ID1";
        String firstName = "John";
        String lastName = "Doe";
        String course = "Computer Science";
        int age = 20;

        // Act
        Student newStudent = new Student(studentID, firstName, lastName, course, age);
        studentList.add(newStudent);

        // Assert
        assertEquals(1, studentList.size(), "Student list should contain 1 student");
        Student savedStudent = studentList.get(0);
        assertEquals(studentID, savedStudent.getStudentID(), "Student ID should match");
        assertEquals(firstName, savedStudent.getFirstName(), "First name should match");
        assertEquals(lastName, savedStudent.getLastName(), "Last name should match");
        assertEquals(course, savedStudent.getCourse(), "Course should match");
        assertEquals(age, savedStudent.getAge(), "Age should match");
    }

    @Test
    public void testSearchStudent() {
        // Arrange
        String studentID = "ID1";
        String firstName = "John";
        String lastName = "Doe";
        String course = "Computer Science";
        int age = 20;
        Student newStudent = new Student(studentID, firstName, lastName, course, age);
        studentList.add(newStudent);

        // Act
        Student foundStudent = Student.SearchStudent(studentID, studentList);

        // Assert
        assertNotNull(foundStudent, "Student should be found");
        assertEquals(studentID, foundStudent.getStudentID(), "Student ID should match");
        assertEquals(firstName, foundStudent.getFirstName(), "First name should match");
        assertEquals(lastName, foundStudent.getLastName(), "Last name should match");
        assertEquals(course, foundStudent.getCourse(), "Course should match");
        assertEquals(age, foundStudent.getAge(), "Age should match");
    }

    @Test
    public void testSearchStudent_StudentNotFound() {
        // Arrange
        String validStudentID = "ID1";
        String invalidStudentID = "ID999";
        String firstName = "John";
        String lastName = "Doe";
        String course = "Computer Science";
        int age = 20;
        Student newStudent = new Student(validStudentID, firstName, lastName, course, age);
        studentList.add(newStudent);

        // Act
        Student foundStudent = Student.SearchStudent(invalidStudentID, studentList);

        // Assert
        assertNull(foundStudent, "Student should not be found");
    }
    @Test
    public void testDeleteStudent() {
        // Arrange
        String studentID = "ID1";
        String firstName = "John";
        String lastName = "Doe";
        String course = "Computer Science";
        int age = 20;
        Student newStudent = new Student(studentID, firstName, lastName, course, age);
        studentList.add(newStudent);

        // Act
        boolean isDeleted = Student.DeleteStudent(studentID, studentList);

        // Assert
        assertTrue(isDeleted, "Student should be deleted");
        assertEquals(0, studentList.size(), "Student list should be empty after deletion");
    }

    @Test
    public void testDeleteStudent_StudentNotFound() {
        // Arrange
        String validStudentID = "ID1";
        String invalidStudentID = "ID999";
        String firstName = "John";
        String lastName = "Doe";
        String course = "Computer Science";
        int age = 20;
        Student newStudent = new Student(validStudentID, firstName, lastName, course, age);
        studentList.add(newStudent);

        // Act
        boolean isDeleted = Student.DeleteStudent(invalidStudentID, studentList);

        // Assert
        assertFalse(isDeleted, "Student should not be deleted if not found");
        assertEquals(1, studentList.size(), "Student list should still contain the original student");
    }

    @Test
    public void testStudentAge_Valid() {
        // Arrange
        int age = 18;

        // Act & Assert
        assertTrue(age >= 16, "Student age should be valid if 16 or older");
    }

    @Test
    public void testStudentAge_Invalid() {
        // Arrange
        int age = 15;

        // Act & Assert
        assertFalse(age >= 16, "Student age should be invalid if under 16");
    }

    @Test
    public void testStudentAge_InvalidCharacter() {
        // Arrange
        String invalidInput = "abc";

        // Act & Assert
        try {
            int age = Integer.parseInt(invalidInput);
            fail("Expected NumberFormatException to be thrown");
        } catch (NumberFormatException e) {
            assertTrue(true, "NumberFormatException was thrown as expected");
        }
}
}

