package abccollege;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;
//Created a Student class with all the student attributes
public class Student {
    private String studentID;
    private String firstName;
    private String lastName;
    private String course;
    private int age;

    // Constructor
    public Student(String studentID, String firstName, String lastName, String course, int age) {
        this.studentID = studentID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.course = course;
        this.age = age;
    }

    // Getters and Setters
    public String getStudentID() { return studentID; }
    public void setStudentID(String studentID) { this.studentID = studentID; }

    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }

    public String getCourse() { return course; }
    public void setCourse(String course) { this.course = course; }

    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }

    // Method to capture student details
    public static void CaptureStudent(ArrayList<Student> studentList) {
        Scanner scanner = new Scanner(System.in);
        boolean addMore = true;

        while (addMore) {
            String studentID, firstName, lastName, course;
            int age = 0;

            // Prompt user to enter student details
            System.out.print("Enter Student ID: ");
            studentID = scanner.nextLine();

            System.out.print("Enter First Name: ");
            firstName = scanner.nextLine();

            System.out.print("Enter Last Name: ");
            lastName = scanner.nextLine();

            System.out.print("Enter Course: ");
            course = scanner.nextLine(); 

            // Validate age input
            
            // Code attribution:
            // This code was adapted from a Stack Overflow post by [Omari Victor Omosa].
            // Original post: [https://stackoverflow.com/questions/38812528/validate-input-using-try-catch]
            // Accessed on: [03/09/2024]
            System.out.print("Enter Age: ");
            while (true) {
                try {
                    age = scanner.nextInt();
                    if (age >= 16) {
                        break; // Valid age entered
                    } else {
                        System.out.println("Age must be 16 or older. Please enter again.");
                    }
                } catch (InputMismatchException e) {
                    System.out.println("Invalid input. Please enter a valid number for the age.");
                    scanner.next(); // Clear the invalid input
                }
            }
            scanner.nextLine(); // Consume newline

            // Create a new Student object and add to the ArrayList
            Student newStudent = new Student(studentID, firstName, lastName, course, age);
            studentList.add(newStudent);

            // Validate the user's response for continuing
            while (true) {
                System.out.print("Do you want to add another student? (yes/no): ");
                String response = scanner.nextLine().trim();

                if (response.equalsIgnoreCase("yes")) {
                    break; // Exit the validation loop and continue adding students
                } else if (response.equalsIgnoreCase("no")) {
                    addMore = false; // Exit both loops and stop adding students
                    break;
                } else {
                    // Handle invalid input by informing the user and prompting again
                    System.out.println("Invalid option. Please enter 'yes' or 'no'.");
                }
            }
        }
    }

    // Method to search for a student
    public static Student SearchStudent(String studentID, ArrayList<Student> studentList) {
        for (Student student : studentList) {
            if (student.getStudentID().equals(studentID)) {
                return student; // Return the found student
            }
        }
        return null; // Return null if not found
    }

    // Method to delete a student
    public static boolean DeleteStudent(String studentID, ArrayList<Student> studentList) {
        Scanner scanner = new Scanner(System.in);

        // Find the student by ID
        Student studentToDelete = null;
        for (Student student : studentList) {
            if (student.getStudentID().equals(studentID)) {
                studentToDelete = student;
                break;
            }
        }

        // If student is found
        if (studentToDelete != null) {
            System.out.println("                                                             ");
            System.out.println("Student found: ");
            System.out.println(studentToDelete);
            
            // Confirm deletion
            System.out.print("Are you sure you want to delete this student? (yes/no): ");
            String response = scanner.nextLine().trim();

            if (response.equalsIgnoreCase("yes")) {
                studentList.remove(studentToDelete);
                System.out.println("                                                             ");
                System.out.println("Student with ID " + studentID + " has been deleted.");
                return true; // Student successfully deleted
            } else {
                System.out.println("                                                             ");
                System.out.println("Deletion canceled.");
                return false; // Deletion canceled
            }
        } else {
            System.out.println("                                                             ");
            System.out.println("Student with ID " + studentID + " cannot be found.");
            return false; // Student not found
        }
    }

    // Method to generate a student report
    public static void StudentReport(ArrayList<Student> studentList) {
        if (studentList.isEmpty()) {
            System.out.println("No students available to display.");
            return;
        }
        int i = 1; 
       
        System.out.println("Student Report:");
        for (Student student : studentList) {
            System.out.println("--------------------------------------------------");
            System.out.println("Student: " + i++);
             System.out.println("--------------------------------------------------");
            System.out.println(student); // Uses the updated toString() method
            System.out.println("--------------------------------------------------");
        }
        
    }

    // Method to exit the application
    public static void ExitStudentApplication() {
        System.out.println("Exiting Student Application.");
        System.exit(0);
    }
    
            // Code attribution:
            // This code was adapted from a Stack Overflow post by [Jack].
            // Original post: [https://stackoverflow.com/questions/11496700/how-to-use-printwriter-and-file-classes-in-java]
            // Accessed on: [03/09/2024]
    public static void exportStudentsToFile(ArrayList<Student> studentList, String fileName) {
        
    // Get the user's home directory
    String userHome = System.getProperty("user.home");
    
    // Define the path to the desktop. This is a generic file path to save on the deskptop of the local computer
    File file = new File(userHome + File.separator + "Desktop" + File.separator + fileName);
    
            // Code attribution:
            // This code was adapted from javabeat.net 
            // Original post: [https://javabeat.net/write-data-csv-file-in-java/]
            // Accessed on: [03/09/2024]
    try (PrintWriter writer = new PrintWriter(file)) { //PrintWriter is used to write the text to the file
        for (Student student : studentList) {          //For loop to iterate through each student
            writer.println(student.getStudentID() + "," +
                            student.getFirstName() + "," +
                            student.getLastName() + "," +
                            student.getCourse() + "," +
                            student.getAge());
        }
        System.out.println("Student list has been exported to " + file.getAbsolutePath());
    } catch (IOException e) {
        System.out.println("An error occurred while writing to the file.");
        e.printStackTrace(); // Print stack trace for debugging
    }
}

    // Override toString() method for easy display
    @Override
    public String toString() {
       return "Student ID: " + studentID + "\n" +
           "First Name: " + firstName + "\n" +
           "Last Name: " + lastName + "\n" +
           "Course: " + course + "\n" +
           "Age: " + age + "\n";
    }
}
