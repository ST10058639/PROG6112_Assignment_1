/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abccollege;
import java.util.ArrayList;
import java.util.Scanner; 
/**
 *
 * @author gculisakolobe
 */
public class AbcCollege {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Student> studentList = new ArrayList<>(); // ArrayList to store Student objects
        
        // Code attribution:
        // This code was adapted from a Stack Overflow post by [user2943817].
        // Original post: [https://stackoverflow.com/questions/19731912/basic-java-menu-with-switch-case]
        // Accessed on: [03/09/2024]
        boolean running = true;
        
        while (running) {
            System.out.println("                                                             ");
            System.out.println("*************************************************************");
            System.out.println("Welcome to the ABC College Student Management System");
            System.out.println("*************************************************************");
            System.out.println("                                                             ");
            
            System.out.println("Enter (1) to launch menu or any other key to exit: ");
            String input = scanner.nextLine();

            if (input.equals("1")) {
                System.out.println("1. Capture Student");
                System.out.println("2. Search Student");
                System.out.println("3. Delete Student");
                System.out.println("4. Student Report");
                System.out.println("5. Export the file");
                System.out.println("6. Exit Application");
                System.out.println("                                                             ");
                System.out.print("Select an option: ");
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                switch (choice) {
                    case 1:
                        Student.CaptureStudent(studentList); // Assumes CaptureStudent handles studentList internally
                        break;

                    case 2:
                        System.out.print("Enter student ID to search: ");
                        String studentID = scanner.nextLine();
                        Student foundStudent = Student.SearchStudent(studentID, studentList);
                        if (foundStudent != null) {
                            System.out.println("--------------------------------------------------");
                            System.out.println("Student Found: ");
                            System.out.println("                                                  ");
                            System.out.println(foundStudent);
                            System.out.println("--------------------------------------------------");
                        } else {
                            System.out.println("--------------------------------------------------");
                            System.out.println("Student with ID: " + studentID + " was not found.");
                            System.out.println("--------------------------------------------------");
                        }
                        break;

                    case 3:
                        System.out.print("Enter student ID to delete: ");
                        String idToDelete = scanner.nextLine();
                        boolean deleted = Student.DeleteStudent(idToDelete, studentList);
                        if (deleted) {
                            System.out.println("Student successfully deleted.");
                        } else {
                            System.out.println("Student not found.");
                        }
                        break;

                    case 4:
                        Student.StudentReport(studentList);
                        break;
                        
                    case 5: 
                         System.out.print("Enter filename to export student list. Ensure file name ends in '.txt': ");
                         String filename = scanner.nextLine();
                         Student.exportStudentsToFile(studentList, filename);
                         System.out.println("Student list has been exported to " + filename);
                    break;

                    case 6:
                        Student.ExitStudentApplication();
                        running = false; // Exit the loop
                        break;
                        
                    default:
                        System.out.println("Invalid choice. Please try again.");
                        break;
                }
            } else {
                System.out.println("Exiting program. Goodbye!");
                running = false; // Exit the loop
            }
        }

        scanner.close(); // Close the scanner after exiting the loop
    }
}